#
# Example file for working with loops
#

def main():
  x = 0

  # define a while loop
  while(x<4):
            print(x);
            x=x+1


  # define a for loop
  for x in range(5,10):
            if (x==6):
                      continue
            print(x)

  # use a for loop over a collection
  days = ["mon","tue","wed","thur","fri"]
  for d in days:
            print(d)
              
 
  # use the break and continue statements


  #using the enumerate() function to get index 


if __name__ == "__main__":
  main()
