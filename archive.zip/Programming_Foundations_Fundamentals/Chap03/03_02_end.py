cookies = 'Sugar'
print(cookies)
print(type(cookies))

cookies = 1
print(cookies)
print(type(cookies))

Cookies = 3
print(Cookies)
print(cookies)

first_name = "Jeff"
print(first_name)

first_Name = "Sara"
print(first_name)
