# Prints out the name of a favorite city
def favorite_city(name):
    print("One of my favorite cities is", name)

favorite_city("Santa Barbara, California")
favorite_city("Asheville, North Carolina")
favorite_city("Amsterdam, The Netherlands")
