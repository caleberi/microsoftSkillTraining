def say_hello():
    print("Hello, friends!")

say_hello()
say_hello()
say_hello()